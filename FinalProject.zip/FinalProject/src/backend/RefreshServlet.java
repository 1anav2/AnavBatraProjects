package backend;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RefreshServlet
 */
@WebServlet("/RefreshServlet")
public class RefreshServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RefreshServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer index = (Integer)request.getSession().getAttribute("index");
		String html = "<div id=\"scheduleContainer\" class=\"z-depth-4\">\n" + 
				"				<table id=\"schedule\" class=\"striped centered responsive-table\">\n" + 
				"					<thead>\n" + 
				"						<tr>\n" + 
				"							<th id=\"scheduleObject\">Year</th>\n" + 
				"							<th id=\"scheduleObject\">Term</th>\n" + 
				"							<th id=\"scheduleObject\" colspan=\"4\">Courses</th>\n" + 
				"						</tr>\n" + 
				"					</thead>\n" + 
				"				<% \n" + 
				"					// CODE TO TEST ========================\n" + 
				"					// ArrayList of Schedules\n" + 
				"					//ArrayList<ArrayList<ArrayList<Course> > > schedules = new ArrayList<ArrayList<ArrayList<Course> > >();\n" + 
				"					// Schedule 1\n" + 
				"					//ArrayList<ArrayList<Course> > schedule1 = new ArrayList<ArrayList<Course> >();\n" + 
				"					// Sem 1 in schedule 1\n" + 
				"					/* ArrayList<Course> sched1sem1 = new ArrayList<Course>();\n" + 
				"					sched1sem1.add(new Course(\"CSCI\", \"350L\", 4));\n" + 
				"					sched1sem1.add(new Course(\"CSCI\", \"360L\", 4));\n" + 
				"					sched1sem1.add(new Course(\"EE\", \"364\", 4));\n" + 
				"					sched1sem1.add(new Course(\"GE\", \"C\", 4)); */\n" + 
				"					//schedule1.add(sched1sem1);\n" + 
				"					// Sem 2 in schedule 1\n" + 
				"					/* ArrayList<Course> sched1sem2 = new ArrayList<Course>();\n" + 
				"					sched1sem2.add(new Course(\"CSCI\", \"401\", 4));\n" + 
				"					sched1sem2.add(new Course(\"Tech\", \"Elec.\", 4));\n" + 
				"					sched1sem2.add(new Course(\"GE\", \"D\", 4));\n" + 
				"					sched1sem2.add(new Course(\"Tech\", \"Elec.\", 4));\n" + 
				"					schedule1.add(sched1sem2); */\n" + 
				"					// Sem 3 in schedule 1\n" + 
				"					/* ArrayList<Course> sched1sem3 = new ArrayList<Course>();\n" + 
				"					sched1sem3.add(new Course(\"Req.\", \"Elec.\", 4));\n" + 
				"					sched1sem3.add(new Course(\"Req.\", \"Elec.\", 4));\n" + 
				"					sched1sem3.add(new Course(\"Tech\", \"Elec.\", 4));\n" + 
				"					sched1sem3.add(new Course(\"GE\", \"D\", 4));\n" + 
				"					schedule1.add(sched1sem3); */\n" + 
				"					//ArrayList<ArrayList<Course>> schedule = schedules.get(0);\n" + 
				"					//schedules.add(schedule1);					\n" + 
				"					//int numOfSemesters = schedule.size();\n" + 
				"					//int index = 0;\n" + 
				"					// CODE TO TEST ========================\n" + 
				"					/* HashMap<String, String []> semesterPlans = new HashMap<String, String []>();\n" + 
				"					int numOfSemesters = 3;\n" + 
				"					String [] semesters = {\"Spring 2018\", \"Fall 2018\", \"Spring 2019\", \"Fall 2019\", \"Spring 2020\"};\n" + 
				"					String [] s18 = {\"CSCI 350L\", \"CSCI 360L\", \"EE 364\", \"GE C\"};\n" + 
				"					String [] f18 = {\"CSCI 401\", \"Tech Elec.\", \"GE D\", \"Tech Elec.\"};\n" + 
				"					String [] s19 = {\"Req. Elec.\", \"Req. Elec.\", \"Tech Elec.\", \"GE D\"};\n" + 
				"					\n" + 
				"					semesterPlans.put(\"Spring 2018\", s18);\n" + 
				"					semesterPlans.put(\"Fall 2018\", f18);\n" + 
				"					semesterPlans.put(\"Spring 2019\", s19); */\n" + 
				"					\n" + 
				"					/* String [] f19 = {\"A\", \"B\", \"C\", \"D\"};\n" + 
				"					String [] s20 = {\"E\", \"F\", \"G\", \"H\"}; */\n" + 
				"					/* semesterPlans.put(\"Fall 2019\", f19);\n" + 
				"					semesterPlans.put(\"Spring 2020\", s20); */\n" + 
				"					// CODE TO TEST ========================\n" + 
				"					String [] semesters = {\"Spring 2018\", \"Fall 2018\", \"Spring 2019\", \"Fall 2019\", \"Spring 2020\", \"Fall 2020\", \"Spring 2021\", \"Fall 2021\"};\n" + 
				"					\n" + 
				"					for (int i = 0; i < schedules.get(index).size(); i++) {\n" + 
				"						String current = semesters[i];\n" + 
				"						String delims = \"[ ]\";\n" + 
				"						String[] tokens = current.split(delims);\n" + 
				"						int maxCourses = 0;\n" + 
				"						for (int j = 0; j < schedules.get(index).size(); j++) {\n" + 
				"							maxCourses = Math.max(schedules.get(index).get(j).size(), maxCourses);\n" + 
				"						}\n" + 
				"						%>\n" + 
				"						<tr>\n" + 
				"							<% if (i % 2 == 0) { %>\n" + 
				"								<td id=\"scheduleObject\"><%= tokens[1] %></td> <%\n" + 
				"							} else { %>\n" + 
				"								<td id=\"scheduleObject\"> </td> <%\n" + 
				"							}\n" + 
				"							%>\n" + 
				"							<td id=\"scheduleObject\"><%= tokens[0] %></td>\n" + 
				"							<% for (int j = 0; j < maxCourses; j++) {\n" + 
				"								if (j < schedules.get(index).get(i).size()) {\n" + 
				"									%><td id=\"scheduleObject\"><%= schedules.get(index).get(i).get(j).getPrefix() %> <%= schedules.get(index).get(i).get(j).getNum() %><br />\n" + 
				"										<font size=\"2\" style=\"font-style: italic\"><%= schedules.get(index).get(i).get(j).getUnits() %> units</font>\n" + 
				"									</td><%\n" + 
				"								} else {\n" + 
				"									%> <td></td> <%\n" + 
				"								}\n" + 
				"							}\n" + 
				"							%>\n" + 
				"						</tr><%\n" + 
				"					}\n" + 
				"					%>\n" + 
				"				</table>\n" + 
				"			</div>";
		response.getWriter().write(html);
	}

}
