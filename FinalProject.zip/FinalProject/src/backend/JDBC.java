package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JDBC {
	
	public void dropSaved(String email) {
		Connection conn = null;
		Connection conn2 = null;
		Connection conn3 = null;
		Connection conn4 = null;
		Connection conn5 = null;
		Statement st = null;
		Statement st2 = null;
		Statement st3 = null;
		Statement st4 = null;
		Statement st5 = null;
		String query = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		ResultSet rs4 = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn2 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn3 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn4 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn5 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			st = conn.createStatement();
			st2 = conn2.createStatement();
			st3 = conn3.createStatement();
			st4 = conn4.createStatement();
			st5 = conn5.createStatement();
			String separator = "\',\'";
			query = "DELETE FROM CoursePlan";
			st.executeUpdate(query);
			query = "DELETE FROM Semester";
			st.executeUpdate(query);
			query = "DELETE FROM CoursesInSemester";
			st.executeUpdate(query);
			//query = "SELECT * FROM Student WHERE email=\'" + email + "\'";
			//rs = st.executeQuery(query);
//			while(rs.next()) 
//			{
//				Integer studentID = rs.getInt("studentID");
//				query = "SELECT * FROM CoursePlan WHERE studentID=" + studentID;
//				rs2 = st2.executeQuery(query);
//				query = "DELETE FROM CoursePlan WHERE studentID=" + studentID;
//				st2.executeQuery(query);
//				if(rs2.next()) {
//					Integer planID = rs2.getInt("planID");
//					query = "SELECT * FROM Semester WHERE planID=" + planID;
//					rs3 = st3.executeQuery(query);
//					query = "DELETE FROM Semester WHERE planID=" + planID;
//					st3.executeQuery(query);
//					while(rs3.next() ) {
//						Integer semesterID = rs3.getInt("semesterID");
//						query = "DELETE FROM CoursesInSemester WHERE semesterID=" + semesterID;
//						st4.executeUpdate(query);
//					}
//				}
//				else {
//					return;
//				}
//			}
			conn.close();
			conn2.close();
			conn3.close();
			conn4.close();
			conn5.close();
		} catch (SQLException | ClassNotFoundException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void save(String email, ArrayList<ArrayList<Course>> savedSchedule) {
		Connection conn = null;
		Connection conn2 = null;
		Connection conn3 = null;
		Connection conn4 = null;
		Connection conn5 = null;
		Statement st = null;
		Statement st2 = null;
		Statement st3 = null;
		Statement st4 = null;
		Statement st5 = null;
		String query = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn2 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn3 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn4 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			conn5 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
			st = conn.createStatement();
			st2 = conn2.createStatement();
			st3 = conn3.createStatement();
			st4 = conn4.createStatement();
			st5 = conn5.createStatement();
			String separator = "\',\'";
			query = "SELECT * FROM Student WHERE email=\'" + email + "\'";
			rs = st.executeQuery(query);
			while(rs.next()) 
			{
				Integer studentID = rs.getInt("studentID");
				//insert course plan
				query = "INSERT INTO CoursePlan (studentID)" + " values (" + studentID + ")";
				st2.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
				Integer coursePlanID = retrieveID(st2);
				//System.out.println("Semester size: " + savedSchedule.size());
				for(ArrayList<Course> semester : savedSchedule)
				{
					//System.out.println("Courses in semester: " + semester.size());
					query = "INSERT INTO Semester (planID)"
							+ " values (" + coursePlanID + ")";
					st3.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
					Integer semesterID = retrieveID(st3);
					for(Course c : semester)
					{
						//System.out.println(c.getPrefix() + " " + c.getNum());
						query = "SELECT * FROM Course WHERE coursePrefix=\'" + c.getPrefix() + "\' AND courseNum=\'" + c.getNum()
						+ "\' AND courseUnits=" + c.getUnits();
						//System.out.println(query);
						rs2 = st4.executeQuery(query);
						Integer courseID = null;
						while(rs2.next()) {
							//System.out.println("Inside course insert");
							courseID = rs2.getInt("courseID");
							//System.out.println(courseID);
							query = "INSERT INTO CoursesInSemester (courseID, semesterID)"
									+ " VALUES (" + courseID + "," + semesterID + ")";
							System.out.println(query);
							st5.executeUpdate(query);
						}
						
					}
				}
			}
			conn.close();
			conn2.close();
			conn3.close();
			conn4.close();
			conn5.close();
		} catch (SQLException | ClassNotFoundException sqle) {
			sqle.printStackTrace();
		}
	}
	
	private Integer retrieveID(Statement st) {
		ResultSet rs;
		Integer id = 0;
		try {
			rs = st.getGeneratedKeys();
			if(rs.next()) {
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	public ArrayList<ArrayList<Course>> retrievePlan(String email)
	{
		Connection conn = null;
		Connection conn2 = null;
		Connection conn3 = null;
		Connection conn4 = null;
		Connection conn5 = null;
		Statement st = null;
		Statement st2 = null;
		Statement st3 = null;
		Statement st4 = null;
		Statement st5 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		ResultSet rs4 = null;
		ResultSet rs5 = null;
		String query = null;
		ArrayList<ArrayList<Course>> schedule = new ArrayList<ArrayList<Course>>();
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
				conn2 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
				conn3 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
				conn4 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
				conn5 = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
				st = conn.createStatement();
				st2 = conn2.createStatement();
				st3 = conn3.createStatement();
				st4 = conn4.createStatement();
				st5 = conn5.createStatement();
				
				query = "SELECT * FROM Student WHERE email =\'" + email + "\'";
				rs = st.executeQuery(query);
				while(rs.next())
				{
					Integer studentID = rs.getInt("studentID");
					rs2 = st2.executeQuery("SELECT * FROM CoursePlan WHERE studentID=" + studentID);
					while(rs2.next()) {
						Integer planID = rs2.getInt("planID");
						rs3 = st3.executeQuery("SELECT * FROM Semester WHERE planID=" + planID);
						while(rs3.next()) {
							ArrayList<Course> semester = new ArrayList<Course>();
							Integer semesterID = rs3.getInt("semesterID");
							rs4 = st4.executeQuery("SELECT * FROM CoursesInSemester WHERE semesterID=" + semesterID);
							while(rs4.next()) {
								Integer courseID = rs4.getInt("courseID");
								rs5 = st5.executeQuery("SELECT * FROM Course WHERE courseID=" + courseID);
								while(rs5.next()) {
									String coursePrefix = rs5.getString("coursePrefix");
									String courseNum = rs5.getString("courseNum");
									Integer courseUnits = rs5.getInt("courseUnits");
									Course c = new Course(coursePrefix, courseNum, courseUnits, 0);
									semester.add(c);
								}
							}
							schedule.add(semester);
						}
						
					}
					
				}
				conn.close();
				conn2.close();
				conn3.close();
				conn4.close();
				conn5.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		 catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return schedule;
	}
}
